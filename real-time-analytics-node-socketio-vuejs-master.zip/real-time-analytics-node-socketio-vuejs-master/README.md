# Creating a Real-Time Analytics Dashboard with NodeJs, Socket.io, and Vue.js

This code is for the tutorial on creating a real-time website analytics dashboard using NodeJs, Socket.io, and Vue.js.

Check out the full tutorial at [coligo](http://coligo.io/real-time-analytics-with-nodejs-socketio-vuejs/)
